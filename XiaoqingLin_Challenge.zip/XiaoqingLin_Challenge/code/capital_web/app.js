var mysql = require('mysql');
var express = require('express');
var app = express();
app.set('view engine', 'ejs')

var connection = mysql.createConnection({
    host: 'capital.cn93mpcfkl9j.us-east-2.rds.amazonaws.com',
    port: '3306',
    user: 'xqinglin',
    password: 'capitalQQ...',
    database: 'capital_data'
});

app.get('/', function(req, res){
    res.render("index");
});
app.get('/revenue', function(req, res){
    var q = 'SELECT year(transaction_date), SUM(transaction_amount) from transactions GROUP BY year(transaction_date);';
    connection.query(q,function(error, results, fields){
        if(error) throw error;
        var dic = {}
        for(var i = 0; i< results.length; i++){
            var year = results[i]["year(transaction_date)"]
            dic[year] = results[i]["SUM(transaction_amount)"]
        }
        var new_res = {'revenue': dic}
        res.send(new_res);
    });

});
app.get('/activeusers', function(req, res){
   var q = 'SELECT year(transaction_date), COUNT(DISTINCT id_user) FROM transactions GROUP BY year(transaction_date);';
    connection.query(q,function(error, results, fields){
        if(error) throw error;
        var dic = {}
        for(var i = 0; i< results.length; i++){
            var year = results[i]["year(transaction_date)"]
            dic[year] = results[i]["COUNT(DISTINCT id_user)"]
        }
        var new_res = {'activeusers': dic}
        res.send(new_res);
    });

});
app.get('/newusercount', function(req, res){
   var q = 'SELECT year(join_data), COUNT(id) from users GROUP BY year(join_data);';
    connection.query(q,function(error, results, fields){
        if(error) throw error;
        var dic = {}
        for(var i = 0; i< results.length; i++){
            var year = results[i]["year(join_data)"]
            dic[year] = results[i]["COUNT(id)"]
        }
        var new_res = {'newusercount': dic}
        res.send(new_res);
    });

});
app.get('/arpau/', function(req, res){
    var q = 'SELECT year(transaction_date) as Year, (SUM(transaction_amount)/COUNT(DISTINCT id_user)) as Average from transactions GROUP BY year(transaction_date);';
    connection.query(q,function(error, results, fields){
        if(error) throw error;
        var dic = {}
        for(var i = 0; i< results.length; i++){
            var year = results[i]["Year"]
            dic[year] = results[i]["Average"]
        }
        var new_res = {'arpau': dic}
        res.send(new_res);
    });

});
app.listen(process.env.PORT, process.env.IP);


