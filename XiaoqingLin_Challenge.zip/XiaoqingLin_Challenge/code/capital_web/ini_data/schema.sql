DROP DATABASE capital_data;
CREATE DATABASE capital_data;
Use capital_data;

CREATE TABLE users(
    id INTEGER PRIMARY KEY,
    join_data DATE
);

CREATE TABLE transactions(
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    transaction_amount FLOAT,
    region varchar(225),
    transaction_date DATE,
    id_user INTEGER  NOT NULL,
    FOREIGN KEY(id_user) REFERENCES users(id)
);

source ini_data/users.sql;
source ini_data/transactions.sql;
