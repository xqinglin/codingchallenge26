
# coding: utf-8

# In[20]:


import csv
import os

def formate_date(date):
    ## map data formate from 'MM/DD/YYYY' to 'YYYY-MM-DD'
    map_month = {'January':'01', 'February':'02', 'March':'03', 'April':'04', 'May':'5',
                 'June':'06', 'July':'07', 'August':'08', 'September':'09', 'October':'10', 
                 'November':'11', 'December':'12'}
    date = date.split('/')
    res = date[2]+'-'+map_month[date[0]]+'-'+date[1]
    return res

def formate_date_2016(date):
    ##20-08-1999
    ## map data formate from 'DD-MM-YYYY' to 'YYYY-MM-DD'
    date = date.split('-')
    if len(date) == 3:
        res = date[2]+'-'+date[1]+'-'+date[0]
    else:
        return ''
    return res

def preprocess_data(file, users, transactions, incomplete):
    ## process the data to a format that sql can use
    ## for incomplete data, save them in a list for later reference
    ## use dictionary to save unique users and their join date
    csv_file = open(file)
    csv_reader = csv.reader(csv_file, delimiter=',')
    count = 1
    for row in csv_reader:
        current = ''.join(row).split()
        if len(current) == 5 and count != 1:
            user_id = current[0]
            transaction_date = formate_date(current[1])
            amount = current[2]
            join_date = formate_date(current[3])
            region = current[4]
            users[user_id] = join_date
            transactions.append([amount, region, transaction_date, user_id])
        elif count != 1:
            incomplete.append(current)
        count += 1
    csv_file.close()
    return users, transactions,incomplete

def preproces(files):
    ## loop over every document to preprocess the data
    ## initialize the data
    users = {}
    transactions = []
    incomplete = []
    for file in files:
        users, transactions,incomplete = preprocess_data(file, users, transactions, incomplete)
    return users, transactions,incomplete
def preprocess_data_2016(file6, users6, transactions6, incomplete6):
    ## the csv file for 2016 is different from others, therefore a different preprocess is used here
    csv_file6 = open(file6)
    csv_reader6 = csv.reader(csv_file6, delimiter=',')
    count = 1
    for row in csv_reader6:
        current6 = row
        if len(current6) >= 5 and count != 1:
            user_id6 = current6[0]
            transaction_date6 = formate_date_2016(current6[1])
            amount6 = current6[2]
            join_date6 = formate_date_2016(current6[3])
            region6 = current6[4]
            if join_date6 == '' or transaction_date6 == '':
                incomplete6.append(current6)
            else:
                users6[user_id6] = join_date6
                transactions6.append([amount6, region6, transaction_date6, user_id6])
        elif count != 1:
            incomplete6.append(current6)
        count += 1
    csv_file6.close()
    return users6, transactions6,incomplete6


# In[21]:


## file path
file_2013 = '/Users/lin/Desktop/Data Engineering Challenge/Data/transactions_2013.csv'
file_2014 = '/Users/lin/Desktop/Data Engineering Challenge/Data/transactions_2014.csv'
file_2015 = '/Users/lin/Desktop/Data Engineering Challenge/Data/transactions_2015.csv'
file_2016 = '/Users/lin/Desktop/Data Engineering Challenge/Data/transactions_2016.csv'
files = [file_2013, file_2014, file_2015]


## call the function to pre-process the date to the right format
users, transactions,incomplete = preproces(files)
users, transactions,incomplete = preprocess_data_2016(file_2016, users, transactions, incomplete)


# In[22]:


user_file = open('users.sql', 'w')
user_file.write('insert into users(id, join_data) VALUES ')
current_user = ''
for user in users:
    if current_user != '':
        current_user += ','
    current_user += '("' + user + '","' + users[user]+ '")'
user_file.write(current_user)
user_file.write(';')
user_file.close()


# In[23]:


transaction_file = open('transactions.sql', 'w')
transaction_file.write('insert into transactions(transaction_amount, region, transaction_date, id_user) VALUES ')
current_transactions = ''
for transaction in transactions:
    amount = transaction[0]
    region = transaction[1]
    transaction_date = transaction[2]
    user_id = transaction[3]
    if current_transactions != '':
        current_transactions += ','
    current_transactions += '("'+amount +'","'+region+'","'+transaction_date+'","'+user_id+'")'
transaction_file.write(current_transactions)
transaction_file.write(';')
transaction_file.close()

